<div class="wrap">
    <h1 class="wp-heading-inline"><?php echo esc_html( get_admin_page_title() ); ?></h1>

    <hr class="wp-header-end">

    <?php $testListTable->display() ?>
    <br class="clear">
</div>