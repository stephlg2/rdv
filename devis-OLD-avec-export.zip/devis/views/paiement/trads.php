<?php

$title = array('fr' => 'Rendez-vous avec l\'Asie : Règlement de votre voyage','en' => 'rdvasie.com : Payment of your travel');
$titre = array('fr' => 'Règlement de votre voyage','en' => 'Payment of your travel');
$voyage = array('fr' => 'Votre voyage','en' => 'Your travel');
$dest = array('fr' => 'Destination(s)','en' => 'Destination(s) GB');
$devis = array('fr' => 'Date de la demande','en' => 'Request date');
$depart = array('fr' => 'Date de départ','en' => 'Departure date');
$retour = array('fr' => 'Date de retour','en' => 'Return date');
$montant = array('fr' => 'Montant du paiement','en' => 'Payment amount');
$coord = array('fr' => 'Vos coordonnées','en' => 'Your contact details');
$tel = array('fr' => 'Téléphone','en' => 'Phone');
$acces = array('fr' => 'Accèder au paiement','en' => 'Access to payment');
$cic = array('fr' => 'Vous effectuez votre paiement via la plateforme sécurisée Monetico CIC','en' => 'You make your payment via the secure platform Monetico CIC FR');
$traite = array('fr' => 'Votre devis a déjà été traité','en' => 'Your quote has already been processed');
$erreur = array('fr' => 'Si ce n\'est pas le cas, nous vous invitons à prendre contact avec nos équipes soit par téléphone au 02 72 64 40 34, soit par email à l\'adresse suivante : contact@rdvasie.com','en' => 'If this is not the case, we invite you to contact our teams either by phone at 02 72 64 40 34, or by email at the following address: contact@rdvasie.com');
$accept = array('fr' => 'Votre paiement a été accepté','en' => 'Votre paiement a été accepté GB');
$conf = array('fr' => 'Merci pour votre confiance','en' => 'Thank you for your trust ');
$question = array('fr' => 'Une question','en' => 'A question');
$cancel = array('fr' => 'Votre paiement a été annulé','en' => 'Your payment has been canceled');
$souci = array('fr' => 'Vous avez rencontré un souci','en' => 'You have encountered a problem');
$appel = array('fr' => 'N\'hésitez pas à nous appeler au','en' => 'Call us at');
$mail = array('fr' => 'Ou par mail','en' => 'Or mail');
