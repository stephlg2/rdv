<div class="post-content">
    <h2 style="text-align: center;">Votre demande de devis a bien été envoyée, merci !</h2>
    <p style="text-align: center;"><strong>Nous vous contacterons très rapidement.</strong><br>
        <em>Toute l’équipe de Rendez-vous avec l’Asie</em></p>
</div>
